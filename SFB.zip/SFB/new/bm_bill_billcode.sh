. $HOME/OM_CONFIG

if [ ! "$OM_PROG" ] || [ ! "$OM_INPUT" ] || [ ! "$OM_OUTPUT" ]
then
echo "Error Critical Environment not defined - OM_PROG[$OM_PROG] OM_INPUT[$OM_INPUT] OM_OUTPUT[$OM_OUTPUT] !!!"
exit -1
fi

echo "`date` - load_bm_billcode start running"

FILE_PATH=$OM_INPUT/dw
FILE_NAME=bm_bill_code_`date +%Y%m%d`.txt
FILE_COMPLETE=bm_bill_code_`date +%Y%m%d`.complete

CTL_FILE=$OM_OUTPUT/cronjob/OM_JOB/bm_bill_code.ctl
COL_FILE=$OM_PROG/cronjob/OM_JOB/upload_dw_data/bm_bill_code.col
LOG_FILE=$OM_OUTPUT/cronjob/logs/bm_bill_code_$(date "+%Y%m%d").log
SQLLDR_LOG=$OM_OUTPUT/cronjob/logs/bm_bill_code_sql.log
SQLLDR_BAD=$OM_OUTPUT/cronjob/logs/bm_bill_code_sql.bad

ADMIN_MAIL=$ADMIN_EMAIL

cd $FILE_PATH

if [ ! -f $FILE_NAME ] || [ ! -f $FILE_COMPLETE ]
then
  echo "Missing input file from DW"
  echo "Missing input file ${FILE_PATH}/${FILE_NAME} from DW" | mutt -s "[ERROR] Load BM Bill Code" $ADMIN_MAIL
  exit 1;
fi

# Get the name of the table to load the data
load_table=`sqlplus -s $ORA_LOGNAME <<end
set pagesize 0 feedback off ver off heading off echo off
  SELECT view_use_table
    FROM om_view_table
   WHERE view_used_ind = 'N'
     AND view_table_name = 'OM_BM_BILL_CODE'
     AND ROWNUM = 1
ORDER BY view_load_date;
exit;
end`

# Get the name of the table using now
org_table=`sqlplus -s $ORA_LOGNAME <<end
set pagesize 0 feedback off ver off heading off echo off
  SELECT view_use_table
    FROM om_view_table
   WHERE view_used_ind = 'Y'
     AND view_table_name = 'OM_BM_BILL_CODE'
     AND ROWNUM = 1;
exit;
end`

# Truncate the original table
sqlplus -s /nolog <<EOF 1>> $LOG_FILE 2>&1
CONNECT $ORA_LOGNAME
  call om_lib.trunc_tbl('$load_table');
EOF
echo `date` "Finish trunc table "$load_table

# Load data from file to database
echo 'LOAD DATA' > $CTL_FILE
echo 'INFILE "'$FILE_NAME'"' >> $CTL_FILE
echo 'APPEND' >> $CTL_FILE
echo 'INTO TABLE '$load_table >> $CTL_FILE
cat $COL_FILE >> $CTL_FILE

sqlldr userid=$ORA_LOGNAME control=$CTL_FILE silent=feedback direct=true skip_index_maintenance=false log=$SQLLDR_LOG bad=$SQLLDR_BAD

retcode=`echo $?`
# Grep Reserve Error Code from logfile
grep -e "SQL\*Loader-" -e "ORA-" $SQLLDR_LOG >> $LOG_FILE
case "$retcode" in
0) echo "SQL*Loader execution successful with EX_SUCC (bm_billcode)">> $LOG_FILE;;
1) echo "SQL*Loader execution with EX_FAIL (bm_billcode)">> $LOG_FILE;;
2) echo "SQL*Loader execution with EX_WARN (bm_billcode)">> $LOG_FILE;;
3) echo "SQL*Loader execution encountered a fatal error (bm_billcode)">> $LOG_FILE;;
*) echo "unkown return code (bm_billcode)">> $LOG_FILE; exit 1;;
esac

if [ $retcode -ne 0 ]; then
  if [ $retcode -ne 2 ]; then
     echo "ERROR: SQL-LOADER get error on `date`" >> $LOG_FILE
     echo "ERROR: SQL-LOADER data on `date`"| mutt -s "Load BM Bill Code failed" -a $SQLLDR_LOG $ADMIN_MAIL
     exit 1
  else
     echo "WARNING: SQL-LOADER get error on `date`. Process continues." >> $LOG_FILE
     echo "WARNING: SQL-LOADER data on `date`"| mutt -s "Load BM Bill Code failed" -a $SQLLDR_LOG $ADMIN_MAIL
     exit 1
  fi
else
  echo "Load BM Bill Code Successful on `date`" >> $LOG_FILE
fi

# Swap the table of the view
echo "Start swaping table of view on `date`" >> $LOG_FILE
sqlplus -s /nolog <<EOF 1>> $LOG_FILE 2>&1
CONNECT $ORA_LOGNAME
WHENEVER SQLERROR EXIT SQL.SQLCODE
SET FEEDBACK OFF
SET SERVEROUTPUT ON
DECLARE
  vResult   NUMBER;
  vErrMsg   VARCHAR2(200);
BEGIN
  om_lib.swap_view_table('om','OM_BM_BILL_CODE','$load_table',vResult,vErrMsg);
  dbms_output.put_line('Result code: ' || vResult);
  IF vResult <> 0 THEN
    dbms_output.put_line('Error message: ' || vErrMsg);
  END IF;
END;
/
EOF

echo "`date` - load_bm_billcode finish running"


