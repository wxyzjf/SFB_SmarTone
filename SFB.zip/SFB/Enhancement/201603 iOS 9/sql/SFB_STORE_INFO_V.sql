set serveroutput on
set timing       on

declare
    lv_sTbleName     VARCHAR2(30);
begin
    dbms_output.enable(100000000000);

    SELECT param_code1
      INTO lv_sTbleName
      FROM sfb_param
     where param_name = 'STORE_INFO'
       AND param_type = 'LIVE_TABLE'
       AND status = 'A';
    
    sfb_lib.sp_DynExecuteSQL('
        CREATE OR REPLACE VIEW SFBADM.SFB_STORE_INFO_V
        (
         STORE_CODE,
         STORE_EMAIL,
         STORE_CLOSE_DATE,
         STORE_STATUS,
         RBD_UNIT_ID,
         IN_CHRG_SALES_MGR,
         IN_CHRG_SALES_MGR_EMAIL,
         MANAGER_NAME,
         PHONE_NO,
         LAST_UPD_DATE
        ) AS
        SELECT RBD_UNIT_CODE,
               EMAIL_ADDRESS,
               STORE_CLOSE_DATE,
               CASE
                  WHEN (STORE_CLOSE_DATE IS NULL
                        OR STORE_CLOSE_DATE >= TRUNC (SYSDATE))
                  THEN
                     ''A''
                  ELSE
                     ''O''
               END,
               RBD_UNIT_ID,
               IN_CHRG_SALES_MGR,
               IN_CHRG_SALES_MGR_EMAIL,
               IN_CHRG_MGR_FULLNAME,
               PHONE_NO,
               LAST_UPD_DATE
        FROM ' || lv_sTbleName || ' 
       WHERE IN_CHRG_SALES_MGR_EMAIL IS NOT NULL');
exception
    when others then
        dbms_output.put_line('Error ' || SQLERRM);
end;
/


